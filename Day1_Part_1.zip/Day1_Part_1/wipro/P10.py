x = 12
y = 15
formatStr = '{0} + {1} = {2}; {0} * {1} = {3}'
result = formatStr.format(x, y, x+y, x*y)
print(result)