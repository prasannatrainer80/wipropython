students = ["Arjit","Bala","Sindhu","Sravanthi","Rucha","Debashis","Mithun","Mohan"]
print(students)
print(students[-1])
print(students[-3:])
print(students[:-3])

print(students[:-3:-1])
