students = ["Arjit", "Bala", "Sindhu", "Sravanthi", "Rucha", "Debashis", "Mithun", "Mohan"]
i = 0
n = len(students)
while i < n:
    if students[i]== "Rucha":
        print("Name Found  ", students[i])
        break

    print(students[i])
    i = i + 1


