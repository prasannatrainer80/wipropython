print("Welcome to Python")
print("Mohan Raj " *2)
print("Hi " + " I am Debashis " + " Attending Python Training")