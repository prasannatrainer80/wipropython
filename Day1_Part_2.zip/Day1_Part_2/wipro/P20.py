n = 10
i = 0
while i < n :
    print("Welcome to Python...")
    i=i+1

