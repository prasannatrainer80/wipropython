students = ["Arjit", "Rucha", "Debashis", "Prasanna"]
for x in students:
    if x== "Rucha":
        print("Hi I am Attending Python Training...")
    if x == "Debashis":
        print("Hi I Installed Python...")
    if x == "Arjit":
        print("Hi I am Practicing Right Now...")
    if x == "Prasanna":
        pass
 #   print(x)
