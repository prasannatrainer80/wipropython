a = 5
b = 7
c = a > b
print(c)
c = a < b
print(c)