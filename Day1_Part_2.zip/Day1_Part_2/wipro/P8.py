sname = input("Enter Student Name  ")
course = input("Enter Course Name  ")
company = input("Enter Company Name  ")
print("Student Name {}  Course Name   {}  Company Name {}".format(sname, course, company))