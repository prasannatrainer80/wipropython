import pandas as pd
import numpy as np

x=pd.Series("Wipro",index=[0,1,2,3])
print(x)