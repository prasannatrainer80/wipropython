# a = 5
# b = 3
# c = a / 0
# print(c)

# a = 5
# b = "Wipro"
# c = a + b
# print(c)

# names = ["Nandini","Yashpal","Rajesh","Kishore"]
# print(names[10])