class Training:

    def trainer(self):
        print("Trainer is Prasanna...")

    @classmethod
    def company(cls):
        print("Company is Wipro")

    @classmethod
    def trainingCompany(cls):
        print("Its Great Learning")

Training.company()
Training.trainingCompany()
training=Training()
training.trainer()