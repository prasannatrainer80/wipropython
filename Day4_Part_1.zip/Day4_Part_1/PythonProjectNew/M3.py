class Demo:
    trainingFrom="GL"
    company="Wipro"
    trainer="Prasanna"

demo=Demo()
print(demo.trainingFrom)
print(demo.company)
print(demo.trainer)