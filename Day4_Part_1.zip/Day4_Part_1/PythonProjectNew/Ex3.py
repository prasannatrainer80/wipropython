def listEx():
    names=["Debashis","Utkarsh","Jashwanthi","Nivetha"]
    print(names[10])

listEx()