students = ["Arjit", "Bala", "Sindhu", "Sravanthi", "Rucha", "Debashis", "Mithun", "Mohan"]
for x in students:
    print(x)