status = True
print("Status is ", status)
status = False
print("Status is  ", status)