age = int(input("Enter Your Age   "))
if age >= 18:
    print("You are Elligible for Voting...")
else:
    print("You Cannot Vote...")