def show(firstName, lastName, city, state):
    print("First Name ",firstName)
    print("Last Name ",lastName)
    print("City  ",city)
    print("State ",state)

#show("Srikakulam","AP","Bala","Murali")
show(city="Srikakulam",state="AP",firstName="Bala",lastName="Murali")