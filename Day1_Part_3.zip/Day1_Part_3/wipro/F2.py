def show(name):
    print("Student Name is ", name)

sname=input("Enter Student Name")
show(sname)