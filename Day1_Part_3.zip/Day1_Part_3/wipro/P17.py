employData = {
    "Name":"Prasanna",
    "City":"Hyderabad",
    "Course":"Python",
    "Company":"Wipro"
}

print(type(employData))

print("Employ Name  ", employData["Name"])
print("Employ City  ", employData["City"])
print("Course  ", employData["Course"])
print("Company  ", employData["Company"])