n = int(input("Enter a Number"))
if n >= 0:
    print("Positive Number...")
else:
    print("Negative Number")