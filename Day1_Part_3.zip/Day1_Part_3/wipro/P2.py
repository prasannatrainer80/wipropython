a = 12
b = 13
c = 12.5
company="Wipro"
print(a)
print(b)
print(a+b)
print(company)
print(type(a))
print(type(b))
print(type(company))
print(type(c))

print("Address of Variable ",a ," is ", id(a))
print("Address of Variable ", b , " Is ", id(b))
print("Address of Variable ", company, " Is ", id(company))