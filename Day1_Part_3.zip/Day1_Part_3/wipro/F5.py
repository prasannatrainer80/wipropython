def a_calc(string):
    return len(string)

print("Length is  {}".format(a_calc("Sindhu")))

print("Length is  {}".format(a_calc("Bala Murali")))

print("Length is  {}".format(a_calc("Rucha")))