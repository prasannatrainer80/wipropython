choice =int(input("Enter Your Choice  "))
match choice:
    case 1:
        print("Hi I am Prasanna...")
    case 2:
        print("Hi I am Abhijeet...")
    case 3 :
        print("Hi I am Vinod...")
    case 4 :
        print("Hi I am Jessy...")
    case _ :
        print("Invalid Choice")

