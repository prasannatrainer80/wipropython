students = ["Arjit","Bala","Sindhu","Sravanthi","Rucha","Debashis","Mithun","Mohan"]
print(students)
print("First Student Name  ", students[0])
print("Third Value  ",students[3])
print("Range  ", students[0:3])
print(students[0:5])
print(students[0:5:2])
print(students[0:7])
print(students[0:7:3])