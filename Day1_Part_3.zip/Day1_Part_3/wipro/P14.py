sno = int(input("Enter Your Id  "))
if sno == 1:
    print("Hi I am Arjit...")
elif sno == 2:
    print("Hi I am Debhasis...")
elif sno == 3:
    print("Hi I am Murali Bala...")
elif sno == 4:
    print("Hi I am Sindhu...")
elif sno == 5:
    print("Hi I am Rucha...")
else:
    print("Invalid Name...")