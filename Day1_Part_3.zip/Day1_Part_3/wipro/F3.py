def calc(x,y):
    z=x+y
    print("Sum of {} and {} is {}".format(x, y, z))

x=int(input("Enter First Number  "))
y=int(input("Enter Second Number  "))
calc(x,y)