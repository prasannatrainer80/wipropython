sname = input("Enter Your Name  ")
print("Student Name is  ", sname)