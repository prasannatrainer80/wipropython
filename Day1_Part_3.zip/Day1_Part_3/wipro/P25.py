students = ["Arjit", "Bala", "Sindhu", "Sravanthi", "Rucha", "Debashis", "Mithun", "Mohan"]
for x in students:
    if x== "Rucha":
        continue
    print(x)

