sname = input("Enter Student Name  ")
print("Student Name is {}".format(sname))