def greeting() :
    print("Welcome to Python Programming...")

def company():
    print("Company is Wipro...")

def course():
    print("Course is Python FullStack...")

greeting()
course()
company()