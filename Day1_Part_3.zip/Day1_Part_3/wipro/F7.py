def show(name,city="Hyderabad"):
    print("Name is {} City is {}".format(name, city))

show("Nandini")
show("Mohan","Chennai")