students = ["Arjit", "Bala", "Sindhu", "Sravanthi", "Rucha", "Debashis", "Mithun", "Mohan"]
i = 0
n = len(students)
while i < n:
    if students[i]== "Rucha":
       print(i)
    print(students[i])

