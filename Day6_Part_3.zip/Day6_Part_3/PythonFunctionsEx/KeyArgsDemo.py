def show(empno,name,city,salary):
    print("Employ No  ",empno)
    print("Employ Name ",name)
    print("City is  ", city)
    print("Salary is  ", salary)

show(name="Yashpal",city="Delhi",empno=5,salary=99999.23)
