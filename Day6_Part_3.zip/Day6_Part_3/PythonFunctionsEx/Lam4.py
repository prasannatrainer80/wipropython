upper = lambda  str : str.upper()
length = lambda  str : len(str)
lower = lambda  str : str.lower()

print(upper("Prasanna"))
print(length("Prasanna"))
print(lower("PraSaNNa"))