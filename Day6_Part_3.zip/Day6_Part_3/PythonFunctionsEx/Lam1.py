show = lambda :print("Welcome to Lambda Function...")
show()