import numpy as np

arr1 = np.zeros(4)
print(arr1)
arr2=np.arange(5)
print(arr2)
arr3=np.arange(1,9,2)
print(arr3)
arr4=np.random.rand(4)
print(arr4)