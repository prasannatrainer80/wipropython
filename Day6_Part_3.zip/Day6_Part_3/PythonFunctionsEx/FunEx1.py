def sayHello():
    print("Welcome to Python Programming...")

def topic():
    print("Topic is Python Functions concept is going on")

def company():
    print("Company is Wipro")
    
sayHello()
topic()
company()