a = [12,5,2,132,66,-2,42,88,323,66,-3,-44,22,6,-23]
final_list = list(filter(lambda x : (x%2==0), a))
print(final_list)