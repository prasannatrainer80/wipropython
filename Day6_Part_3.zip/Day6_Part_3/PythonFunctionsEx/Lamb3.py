greeting = lambda  name : print("Hello  ", name)
upper = lambda str : str.upper()
greeting("Prasanna")
print(upper("Prasanna"))
