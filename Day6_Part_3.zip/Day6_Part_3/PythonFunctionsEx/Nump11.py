import numpy as np
org = np.array([1,2,3,1,2,3,1,2,3])
result = np.unique(org)
print(result)