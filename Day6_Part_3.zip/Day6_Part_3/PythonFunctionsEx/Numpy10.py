import numpy as np
org = np.array([1,2,3,1,2,3,1,2,3])
n1 = set(org)
res1=np.array(list(n1))
print(res1)

