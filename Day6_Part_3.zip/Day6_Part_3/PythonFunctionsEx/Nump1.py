import numpy as np


array1=np.array([1,2,3,4])
print(array1)
print(np.__version__)
print(array1[1])
print(array1[1] + array1[2])