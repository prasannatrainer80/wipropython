greeting = lambda :print("Welcome to Python...")
greeting()