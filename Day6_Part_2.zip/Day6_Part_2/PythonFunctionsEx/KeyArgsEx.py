def show(firstName, lastName, city, state):
    print("First Name  ", firstName)
    print("Last Name  ", lastName)
    print("City  ", city)
    print("State  ", state)

show("Hyderabad","Ts","Prasanna","Pappu")
show(city="Hyderabad",state="TS",firstName="Prasanna",lastName="Pappu")