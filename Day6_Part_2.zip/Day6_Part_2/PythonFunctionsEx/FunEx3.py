def add(x, y):
    return x+y

def sub(x, y):
    return x-y

def mult(x, y):
    return x * y

a=int(input("Enter First Number   "))
b=int(input("Enter Second Number   "))
print("Sum is  ", add(a, b))
print("Sub is  ", sub(a, b))
print("Mult is  ", mult(a,b))