lambda_cube = lambda x : x * x * x
print(lambda_cube(12))