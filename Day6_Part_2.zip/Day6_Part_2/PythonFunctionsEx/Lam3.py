add = lambda  a, b : a + b
sub = lambda  a, b : a - b
mult = lambda  a, b : a * b

a =int(input("Enter First Number  "))
b = int(input("Enter Second Number  "))
print("Sum is  ", add(a,b))
print("Sub is  ", sub(a, b))
print("Mult is  ", mult(a, b))
