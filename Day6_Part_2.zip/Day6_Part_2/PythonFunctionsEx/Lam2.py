show = lambda name : print("Student Name is ", name)
show("Sravanthi")
show("Rajesh")