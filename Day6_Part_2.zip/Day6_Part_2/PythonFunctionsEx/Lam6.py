Max = lambda a, b : a if a > b else b
Min = lambda a, b : a if a < b else b
print(Max(12,5))
print(Min(12,5))