def attendance(*students):
    for i in students:
        print(i, end=" ")
    print()

attendance()
attendance("Nivedha", "Mohan")
attendance("Nivedha","Utkarsh","Yashpal")
attendance("Nivedha", "Sravanthi", "Prashanth")