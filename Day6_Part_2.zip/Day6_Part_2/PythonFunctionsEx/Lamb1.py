add = lambda a, b : a + b
sub = lambda a, b : a - b
mult = lambda a,b : a * b
div = lambda  a, b : a / b

print(add(12,5))