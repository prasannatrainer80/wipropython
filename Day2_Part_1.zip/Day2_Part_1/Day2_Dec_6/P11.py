import Calc as c
a=int(input("Enter First Number   "))
b=int(input("Enter Second Number  "))
print("Sum is ",c.add(a, b))
print("Sub is ",c.sub(a, b))
print("Mult is ",c.mult(a, b))