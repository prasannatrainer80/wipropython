class Test:
    def show(self):
        print("Show Method from Class Test")

    def hello(self):
        print("Hello Method from Class Test")

test=Test()
test.show()
test.hello()