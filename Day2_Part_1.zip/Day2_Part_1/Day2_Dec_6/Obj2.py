class Employ:
    def greet(self,student):
        print("Hello ",student, " How Are You...")

    def meeting(self, student):
        print("Hi ",student, " We have meeting from 8.45 to 6 PM")
        
employ=Employ()
employ.greet("Sindhu")
employ.meeting("Sindhu")