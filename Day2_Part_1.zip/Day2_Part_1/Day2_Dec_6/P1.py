def show():
    print("Welcome to Python Programming...")
    print("From Wipro ")
    print("Trainer is Prasanna")

show()