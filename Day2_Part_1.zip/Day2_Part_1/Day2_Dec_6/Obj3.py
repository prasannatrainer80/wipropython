class Employ:
    empno=1
    name="Sindhu"
    salary=88323

e1=Employ()
print("Employ No ",e1.empno)
print("Employ Name ",e1.name)
print("Salary  ",e1.salary)