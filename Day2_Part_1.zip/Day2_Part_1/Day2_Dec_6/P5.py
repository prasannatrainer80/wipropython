def show():
    names = ["Jaswanthi","Lakshmi","Devnandan","Debashis","Utkarsh"]
    for w in names:
        print(w, len(w))

show()