def showInfo(choice):
    if choice == 1:
        print("Hi I am Mohan Raj")
    elif choice == 2:
        print("Hi I am Mithun K")
    elif choice == 3:
        print("Hi I am Devanandan")
    elif choice == 4:
        print("Hi I am Sindhu...")
    else:
        print("Invalid Choice")

choice=int(input("Enter Choice  "))
showInfo(choice)
