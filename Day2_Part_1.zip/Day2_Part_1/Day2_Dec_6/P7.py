str="Welcome to Python"
for i in str:
    pass
print("Last Char is  ",i)
