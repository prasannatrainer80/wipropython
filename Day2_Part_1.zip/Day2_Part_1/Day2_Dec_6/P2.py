def evenOdd(n):
    if n%2==0:
        print("Even Number")
    else:
        print("Odd Number")

n=int(input())
evenOdd(n)