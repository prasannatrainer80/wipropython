import Calc
a=int(input("Enter First Number   "))
b=int(input("Enter Second Number  "))
print("Sum is ", Calc.add(a, b))
print("Sub is ", Calc.sub(a, b))
print("Mult is  ", Calc.mult(a, b))