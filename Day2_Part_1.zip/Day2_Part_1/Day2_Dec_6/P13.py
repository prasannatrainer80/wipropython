def attendance(dayNo, *students):
    print("Day ",dayNo)
    for i in students:
        print(i)

attendance(1)
attendance(2,"Sai Sravanthi")
attendance(3,"Sai Sravanthi","Nandini")
attendance(4,"Sai","Nandini","Sindhu")