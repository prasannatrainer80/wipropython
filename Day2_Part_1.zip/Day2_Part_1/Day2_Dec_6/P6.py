str="Welcome to Python"
for i in str:
    if i == 'o':
        continue
    print(i)

