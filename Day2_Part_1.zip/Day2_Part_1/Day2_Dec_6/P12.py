def show(*name):
    for i in name:
        print("{} ".format(i))

show()
show("Jashwanthi")
show("Jashwanthi","Nandini")
show("Mithun","Jashwanthi","Sindhu")