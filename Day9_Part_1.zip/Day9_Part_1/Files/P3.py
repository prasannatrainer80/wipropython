with open("c:/files/PivotEx2.py") as file:
    data = file.read()

print(data)