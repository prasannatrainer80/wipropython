file=open("c:/files/PivotEx2.py")
for line in file:
    print(line)