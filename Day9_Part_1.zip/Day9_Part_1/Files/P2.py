file=open("c:/files/PivotEx2.py")
print(file.read())