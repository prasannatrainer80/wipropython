with open("c:/files/test.txt","w") as file:
    file.write("Hello World...!\n")
    file.write("Testing...!\n")
    file.write("See You Soon\n")

