names=["Nandini","Thrisha","Bala","Debashis","Utkarsh"]

print(names[0])
print(names[0:3])

print(names[3:])

for n in names:
    print(n)