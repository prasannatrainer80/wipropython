names = {"Raj", "Manoj", "Kishore", "Sekhar", "Raj", "Manoj", "Kishore", "Sekhar", "Raj", "Manoj", "Kishore", "Sekhar"}
list2 = names.copy()
print(list2)