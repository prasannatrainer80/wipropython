tup1 = ("Raj","Manoj","Kishore")
print(tup1)
print(len(tup1))
tup2 = ("Sravanthi","Rucha","Sindhu")
tup3 = tup1 + tup2
print(tup3)
del tup1
# print(tup1)