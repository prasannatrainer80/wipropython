def show():
    my_set={1,2,3,4,1,2,5,2,4,1}
    print(my_set)

def display():
    names={"Raj","Manoj","Kishore","Sekhar","Raj","Manoj","Kishore","Sekhar","Raj","Manoj","Kishore","Sekhar"}
    print(names)

show()
display()