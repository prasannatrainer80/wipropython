
employs={"empno":1,"name":"Debashis","salary":88225}
def show():
    print("Employ Id  ", employs["empno"])
    print("Employ Name  ", employs["name"])
    print("Salary is  ", employs["salary"])

show()
